USE master
GO
 
CREATE LOGIN DVDApp WITH PASSWORD='dvdapp123'
GO

USE DVDLibrary
GO
 
CREATE USER DVDApp FOR LOGIN DVDApp
GO

GRANT SELECT ON DVDTable TO DVDApp
GRANT INSERT ON DVDTable TO DVDApp
GRANT UPDATE ON DVDTable TO DVDApp
GRANT DELETE ON DVDTable TO DVDApp
GO

Grant Execute On GetAll To DVDApp
Grant Execute On GetById To DVDApp
Grant Execute On DeleteDVD To DVDApp
Grant Execute On EditDVD To DVDApp
Grant Execute On AddDVD To DVDApp
Go
