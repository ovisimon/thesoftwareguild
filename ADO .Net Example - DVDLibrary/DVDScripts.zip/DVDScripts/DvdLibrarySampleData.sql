Use DVDLibrary
Go

Insert Into DVDTable (Title, ReleaseDate, Director, Rating, Notes)
Values('Gladiator', 1997, 'Russel Crowe', 'G', 'Good')
Go

Insert Into DVDTable (Title, ReleaseDate, Director, Rating, Notes)
Values('Pirates', 2001, 'Johnny Deep', 'PG', 'OK')
Go

Insert Into DVDTable (Title, ReleaseDate, Director, Rating, Notes)
Values('Office Space', 1997, 'Nobody Knows', 'PG-13', 'Bad')
Go

Insert Into DVDTable (Title, ReleaseDate, Director, Rating, Notes)
Values('Star Wars', 1977, 'George Lukas', 'G', 'Good')
Go

Insert Into DVDTable (Title, ReleaseDate, Director, Rating, Notes)
Values('The Sting', 1977, 'Robert Redford', 'R', 'Great movie')
Go
