USE [DVDLibrary]
GO

/****** Object:  Table [dbo].[DVDTable]    Script Date: 3/22/2017 1:39:32 PM ******/
DROP TABLE [dbo].[DVDTable]
GO

/****** Object:  Table [dbo].[DVDTable]    Script Date: 3/22/2017 1:39:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DVDTable](
	[Title] [varchar](30) NULL,
	[ReleaseDate] [varchar](10) NULL,
	[Director] [varchar](30) NULL,
	[Rating] [varchar](10) NULL,
	[DVDID] [int] IDENTITY(1,1)	Primary Key
) ON [PRIMARY]

GO

ALTER TABLE DVDTable
ADD Notes varchar(100);

SET ANSI_PADDING OFF
GO