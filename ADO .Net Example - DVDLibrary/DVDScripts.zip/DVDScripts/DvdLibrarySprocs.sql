Use DVDLibrary
Go
Create Procedure GetAll
As
Select * from DVDTable
Go

Use DVDLibrary
Go
Create Procedure GetByID(
	@DVDID int
)
As
Select * From DVDTable Where DVDID = @DVDID
Go

Use DVDLibrary
Go
Create Procedure DeleteDVD(
	@DVDID int
)
As
Delete From DVDTable Where DVDID = @DVDID
Go

Use DVDLibrary
Go
Create Procedure EditDVD(
	@DVDID int, @Title varchar(30), @Director varchar(30), @ReleaseDate varchar(30), @Rating varchar(10), @Notes varchar(100)
)
As
Update DVDTable Set Title = @Title, ReleaseDate = @ReleaseDate, Director = @Director, Rating = @Rating, Notes = @Notes Where DVDID = @DVDID
Go

Use DVDLibrary
Go
Create Procedure AddDVD(
	@Title varchar(30), @Director varchar(30), @ReleaseDate varchar(30), @Rating varchar(10), @Notes varchar(100)
)
As
Insert into DVDTable (Title, ReleaseDate, Director, Rating, Notes)
Values (@Title, @ReleaseDate, @Director, @Rating, @Notes)
Go

Select * from DVDTable